class TooManyStudentsError(Exception):
    pass